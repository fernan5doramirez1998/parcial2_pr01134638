<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfesorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //Agregando campos a la tabla profesor
        Schema::create('profesor', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('idprofesor');
            $table->string('nombre',150);
            $table->string('apellido',150);
            $table->string('dui',150);
            $table->string('telefono',150);
            $table->string('email',150);
            $table->string('clave',150);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profesor');
    }
}
