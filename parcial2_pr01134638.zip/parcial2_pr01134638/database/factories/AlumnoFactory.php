<?php

use Faker\Generator as Faker;

//Agregamos la clase App\Alumno y los campos de la tabla

$factory->define(App\Alumno::class, function (Faker $faker) {
    return [
        'nombre' => $faker->name,
        'apellido' => $faker->lastname,
        'fechanacimiento' => $faker->date,
        'dirección' => $faker->address,
        'genero' => $faker->sentence(2),
        'telefono' => $faker->phoneNumber,
        'clave' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', // secret
        'correo' => $faker->unique()->safeEmail,
    
    ];
});
