<?php

use Faker\Generator as Faker;

//Agregamos la clase App\Profesor y los campos de la tabla

$factory->define(App\Profesor::class, function (Faker $faker) {
    return [
        'nombre' => $faker->name,
        'apellido' => $faker->lastname,
        'dui' => $faker->sentence(2),
        'telefono' => $faker->phoneNumber,
        'email' => $faker->unique()->safeEmail,
        'clave' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', // secret
        
    ];
});
