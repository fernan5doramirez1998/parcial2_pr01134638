-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 20-09-2021 a las 19:52:46
-- Versión del servidor: 5.7.33-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbrnotas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `idalumno` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechanacimiento` date NOT NULL,
  `dirección` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genero` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`idalumno`, `nombre`, `apellido`, `fechanacimiento`, `dirección`, `genero`, `telefono`, `correo`, `clave`, `created_at`, `updated_at`) VALUES
(1, 'Cristian Daniel', 'Gómez Arana', '1998-12-09', 'Comunidad los Robles, La Paz', 'Masculino', '2296-9087', 'gomez@gmail.com', '$2y$10$Nlv1HWYpkm3iVACr8ZwGm.7NQ/alrco0DWF4l9P8BX0vK7YA2d1VK', NULL, NULL),
(2, 'Fernando', 'Ramírez', '1999-03-05', 'Colonia Montelimar', 'M', '2254-5678', 'fer@gmail.com', '$2y$10$O26CBqiOFHbTdODF8UDfruHWoddi1mdN6LlsBh0H3mSZLZwGmmeQS', NULL, NULL),
(3, 'Yovani', 'Martínez', '1989-12-12', 'Comunidad El comercio,San Miguel', 'M', '6453-9843', 'yovani@gmail.com', '$2y$10$9D9IXapmT/PrcZdI/ESufOKVOEtpHNOwDzMwo4pTKNUE0z4Yiy1EC', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(4, 'Nyah Schimmel', 'Schaefer', '2015-09-19', '958 Larson Inlet\nEunabury, TN 70701-0609', 'Laborum aperiam sed.', '584.487.2665 x2238', 'geovany43@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(5, 'Dortha Cummerata', 'Kessler', '1971-10-31', '606 Lisa Port Suite 331\nEast Reannafurt, AK 22841', 'Et dicta.', '+1 (802) 709-2327', 'judge55@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(6, 'Augustine Rowe IV', 'Bayer', '1976-01-02', '8911 Simonis Junction Suite 512\nKunzeberg, SD 95043', 'Sit minima.', '1-863-596-4846 x7496', 'qsimonis@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(7, 'Marion Stoltenberg', 'Gibson', '2005-08-15', '673 Gibson Rapid\nPort Nellieview, ND 91500', 'Et quisquam quisquam.', '870.679.5689 x549', 'pweber@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(8, 'Eleanore Wyman', 'Bernhard', '2001-09-06', '18580 Shanel Fall Suite 117\nEast Verdiemouth, AK 56929', 'Ratione voluptas.', '+1 (320) 897-8025', 'evie.wyman@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:42', '2021-09-21 06:51:42'),
(9, 'Elwin Schoen', 'Jones', '1999-05-26', '43744 Bayer Parkway Suite 540\nZulaufberg, MO 74029', 'Eum iusto ducimus.', '+1.319.419.1256', 'bogan.maurice@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(10, 'Elian Morar', 'Wiza', '2007-09-19', '8877 Bradly Fort\nSouth Percival, SD 11889-4293', 'Recusandae similique quas.', '485-586-8547 x811', 'randi.spencer@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(11, 'Gunner Ratke', 'Monahan', '2005-03-12', '43912 Isom Spurs\nNakiaport, AZ 61850', 'Omnis a quos.', '+12276093180', 'bschmidt@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(12, 'Adonis Kertzmann', 'Hahn', '2008-03-24', '7277 Norma Track\nJamelchester, OR 70037', 'Omnis consequuntur eum.', '(384) 981-8394', 'brekke.maye@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(13, 'Tobin Ortiz', 'Roob', '2004-10-16', '233 Parisian Square\nBergnaumchester, NH 08000-9327', 'Repudiandae quasi id.', '846-689-8584', 'joe.hoppe@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(14, 'Adrien Grimes PhD', 'Pollich', '2015-04-22', '999 Marilou Stream\nArmaniside, KS 39933-3626', 'Excepturi voluptas.', '(429) 631-3468 x98358', 'bhodkiewicz@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(15, 'Aurelie Becker', 'Boyle', '1992-09-14', '345 Feest Forge\nEvangelinestad, IL 35033-6128', 'Ea qui sed.', '690-447-6776 x430', 'wlittle@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(16, 'Catalina Robel', 'Wintheiser', '2017-01-19', '764 Bergnaum Extension Apt. 843\nLake Craig, WI 36189', 'Eligendi maiores et.', '+18607286807', 'mmueller@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(17, 'Creola Kilback', 'Welch', '2013-02-19', '68500 Judy Path Suite 170\nLake Hal, SC 09292-5312', 'Aut est facere.', '969.942.3396', 'sprice@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(18, 'Karley Senger', 'Corkery', '2017-09-11', '184 Helene Ways\nShermanchester, CA 93666', 'Et veritatis.', '1-701-815-1794 x11424', 'mayer.selena@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(19, 'Nelle Heathcote', 'Welch', '1982-01-10', '8120 Hettinger Drives\nPort Simone, MS 01479', 'Voluptas et.', '985.575.1157 x3685', 'schmidt.ayana@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:43', '2021-09-21 06:51:43'),
(20, 'Paige Morar II', 'Olson', '2015-07-17', '2587 Kuhn Turnpike Apt. 905\nMullermouth, CT 35120-3237', 'Iste eos sapiente.', '(657) 427-4656 x494', 'noemie01@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:44', '2021-09-21 06:51:44'),
(21, 'Miss Cheyenne Ward II', 'Heaney', '2015-06-26', '90193 Hudson Keys\nHeatherton, AL 16771-3155', 'Magni unde repudiandae.', '693-547-1108 x15548', 'caden72@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:44', '2021-09-21 06:51:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `idcursos` int(10) UNSIGNED NOT NULL,
  `nombrecurso` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` year(4) NOT NULL,
  `ciclo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idprofesor` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`idcursos`, `nombrecurso`, `anio`, `ciclo`, `idprofesor`, `created_at`, `updated_at`) VALUES
(1, 'Programación III', 2021, '2', 1, NULL, NULL),
(2, 'Redes II', 2021, '2', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(93, '2014_10_12_000000_create_users_table', 1),
(94, '2014_10_12_100000_create_password_resets_table', 1),
(95, '2021_09_19_122542_create_alumnos_table', 1),
(96, '2021_09_19_122723_create_profesor_table', 1),
(97, '2021_09_19_122810_create_cursos_table', 1),
(98, '2021_09_19_122903_create_notas_table', 1),
(99, '2021_09_19_152001_add_foreign_key_notas_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE `notas` (
  `idnotas` int(10) UNSIGNED NOT NULL,
  `nota1` decimal(15,2) NOT NULL,
  `nota2` decimal(15,2) NOT NULL,
  `nota3` decimal(15,2) NOT NULL,
  `nota4` decimal(15,2) NOT NULL,
  `promedio` decimal(15,2) NOT NULL,
  `parcial` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `idalumno` int(10) UNSIGNED NOT NULL,
  `idcursos` int(10) UNSIGNED NOT NULL,
  `idprofesor` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`idnotas`, `nota1`, `nota2`, `nota3`, `nota4`, `promedio`, `parcial`, `created_at`, `updated_at`, `idalumno`, `idcursos`, `idprofesor`) VALUES
(1, '10.00', '10.00', '10.00', '9.00', '9.50', '10.00', NULL, NULL, 1, 1, 1),
(2, '10.00', '9.00', '9.00', '10.00', '8.00', '9.00', NULL, NULL, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `idprofesor` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dui` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`idprofesor`, `nombre`, `apellido`, `dui`, `telefono`, `email`, `clave`, `created_at`, `updated_at`) VALUES
(1, 'Jorge Alberto', 'Coto Zelaya', '96543810-5', '7577-9087', 'coto@gmail.com', '$2y$10$0GWK.K24XpWVhkosENr3teBfDHKLfLRPRnar6Lrp8ERrsBrYPSsZm', NULL, NULL),
(2, 'Andrés', 'Romero', '06754398-6', '7354-1973', 'romero@gmail.com', '$2y$10$ud5UkNUs09zgVnPpUHjtuOrx0JxZpBZPHJaAlDfZBdp3lpHcGVire', NULL, NULL),
(3, 'Prof. Ken Johnson', 'Friesen', 'Repudiandae numquam reprehenderit.', '434-315-5437 x0934', 'bianka78@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:44', '2021-09-21 06:51:44'),
(4, 'Dora O\'Connell', 'Tillman', 'Enim nobis.', '1-336-585-8975 x4373', 'schulist.layla@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:44', '2021-09-21 06:51:44'),
(5, 'Jamison Keebler', 'McCullough', 'Minus est.', '+1.404.731.8582', 'elisha.romaguera@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(6, 'Crawford Metz', 'Crist', 'Impedit molestiae vero.', '(663) 536-1582 x8023', 'elouise01@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(7, 'Mr. Orin Streich', 'Orn', 'Aut suscipit sint.', '871-308-9900 x9564', 'tturner@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(8, 'Dr. Maxwell Beier', 'Rolfson', 'A reprehenderit est.', '(657) 701-8245 x9302', 'uhowe@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(9, 'Prof. Raleigh Heathcote', 'Wilderman', 'Quia repudiandae.', '1-994-292-8578 x52881', 'abbott.braulio@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(10, 'Laurence Veum Sr.', 'Turcotte', 'Possimus dolores.', '323.505.3138 x493', 'ryan.doyle@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(11, 'Mrs. Palma Morar', 'Gibson', 'Veniam ut qui.', '(509) 757-9142 x07321', 'felton24@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(12, 'Jazlyn Wilkinson', 'Brakus', 'Quos at.', '280.432.0265 x9777', 'nicolas.aidan@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(13, 'Elza Turcotte', 'Hauck', 'Est maxime.', '974-307-5634 x6979', 'zita11@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(14, 'Alene Davis', 'Walsh', 'Mollitia impedit ut.', '(381) 883-9173 x03685', 'ambrose.langosh@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(15, 'Mrs. Elise Oberbrunner IV', 'Mosciski', 'Cumque laudantium mollitia.', '328.953.1756', 'shomenick@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(16, 'Adriana Kohler', 'Effertz', 'Ducimus qui.', '+1 (516) 601-4949', 'tyson64@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:45', '2021-09-21 06:51:45'),
(17, 'Andy Kohler', 'Fisher', 'Quasi reprehenderit labore.', '(610) 708-5231', 'arlene.bednar@example.net', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:46', '2021-09-21 06:51:46'),
(18, 'Angeline Wehner', 'Pacocha', 'Qui delectus.', '+1 (548) 697-0353', 'eudora.koch@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:46', '2021-09-21 06:51:46'),
(19, 'Roderick Bogisich', 'Kuhlman', 'Et voluptas.', '+15734869612', 'louie87@example.org', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:46', '2021-09-21 06:51:46'),
(20, 'Dr. Sophie West I', 'Hand', 'Laudantium natus.', '(812) 487-3447 x8071', 'zrohan@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', '2021-09-21 06:51:46', '2021-09-21 06:51:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`idalumno`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`idcursos`),
  ADD KEY `cursos_idprofesor_foreign` (`idprofesor`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`idnotas`),
  ADD KEY `notas_idalumno_foreign` (`idalumno`),
  ADD KEY `notas_idcursos_foreign` (`idcursos`),
  ADD KEY `notas_idprofesor_foreign` (`idprofesor`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`idprofesor`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `idalumno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `idcursos` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;
--
-- AUTO_INCREMENT de la tabla `notas`
--
ALTER TABLE `notas`
  MODIFY `idnotas` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `idprofesor` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD CONSTRAINT `cursos_idprofesor_foreign` FOREIGN KEY (`idprofesor`) REFERENCES `profesor` (`idprofesor`);

--
-- Filtros para la tabla `notas`
--
ALTER TABLE `notas`
  ADD CONSTRAINT `notas_idalumno_foreign` FOREIGN KEY (`idalumno`) REFERENCES `alumnos` (`idalumno`),
  ADD CONSTRAINT `notas_idcursos_foreign` FOREIGN KEY (`idcursos`) REFERENCES `cursos` (`idcursos`),
  ADD CONSTRAINT `notas_idprofesor_foreign` FOREIGN KEY (`idprofesor`) REFERENCES `profesor` (`idprofesor`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
